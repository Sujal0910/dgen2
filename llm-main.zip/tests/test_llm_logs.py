import datetime
import json
import pathlib
import re
import sys
import textwrap
import time

import pytest
import sqlite_utils
import yaml
from click.testing import CliRunner
from ulid import ULID

from llm import Fragment
from llm.cli import cli
from llm.migrations import migrate
from llm.utils import monotonic_ulid

SINGLE_ID = "5843577700ba729bb14c327b30441885"
MULTI_ID = "4860edd987df587d042a9eb2b299ce5c"


@pytest.fixture
def log_path(user_path):
    log_path = str(user_path / "logs.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    start = datetime.datetime.now(datetime.timezone.utc)
    db["responses"].insert_all(
        {
            "id": str(monotonic_ulid()).lower(),
            "system": "system",
            "prompt": "prompt",
            "response": 'response\n```python\nprint("hello word")\n```',
            "model": "davinci",
            "datetime_utc": (start + datetime.timedelta(seconds=i)).isoformat(),
            "conversation_id": "abc123",
            "input_tokens": 2,
            "output_tokens": 5,
        }
        for i in range(100)
    )
    return log_path


@pytest.fixture
def schema_log_path(user_path):
    log_path = str(user_path / "logs_schema.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    start = datetime.datetime.now(datetime.timezone.utc)
    db["schemas"].insert({"id": SINGLE_ID, "content": '{"name": "string"}'})
    db["schemas"].insert({"id": MULTI_ID, "content": '{"name": "array"}'})
    for i in range(2):
        db["responses"].insert(
            {
                "id": str(ULID.from_timestamp(time.time() + i)).lower(),
                "system": "system",
                "prompt": "prompt",
                "response": '{"name": "' + str(i) + '"}',
                "model": "davinci",
                "datetime_utc": (start + datetime.timedelta(seconds=i)).isoformat(),
                "conversation_id": "abc123",
                "input_tokens": 2,
                "output_tokens": 5,
                "schema_id": SINGLE_ID,
            }
        )
    for j in range(4):
        db["responses"].insert(
            {
                "id": str(ULID.from_timestamp(time.time() + j)).lower(),
                "system": "system",
                "prompt": "prompt",
                "response": '{"items": [{"name": "one"}, {"name": "two"}]}',
                "model": "davinci",
                "datetime_utc": (start + datetime.timedelta(seconds=i)).isoformat(),
                "conversation_id": "abc456",
                "input_tokens": 2,
                "output_tokens": 5,
                "schema_id": MULTI_ID,
            }
        )

    return log_path


datetime_re = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")
id_re = re.compile(r"id: \w+")


@pytest.mark.parametrize("usage", (False, True))
def test_logs_text(log_path, usage):
    runner = CliRunner()
    args = ["logs", "-p", str(log_path)]
    if usage:
        args.append("-u")
    result = runner.invoke(cli, args, catch_exceptions=False)
    assert result.exit_code == 0
    output = result.output
    # Replace 2023-08-17T20:53:58 with YYYY-MM-DDTHH:MM:SS
    output = datetime_re.sub("YYYY-MM-DDTHH:MM:SS", output)
    # Replace id: whatever with id: xxx
    output = id_re.sub("id: xxx", output)
    expected = (
        (
            "# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx\n\n"
            "Model: **davinci**\n\n"
            "## Prompt\n\n"
            "prompt\n\n"
            "## System\n\n"
            "system\n\n"
            "## Response\n\n"
            'response\n```python\nprint("hello word")\n```\n\n'
        )
        + ("## Token usage\n\n2 input, 5 output\n\n" if usage else "")
        + (
            "# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx\n\n"
            "Model: **davinci**\n\n"
            "## Prompt\n\n"
            "prompt\n\n"
            "## Response\n\n"
            'response\n```python\nprint("hello word")\n```\n\n'
        )
        + ("## Token usage\n\n2 input, 5 output\n\n" if usage else "")
        + (
            "# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx\n\n"
            "Model: **davinci**\n\n"
            "## Prompt\n\n"
            "prompt\n\n"
            "## Response\n\n"
            'response\n```python\nprint("hello word")\n```\n\n'
        )
        + ("## Token usage\n\n2 input, 5 output\n\n" if usage else "")
    )
    assert output == expected


def test_logs_text_with_options(user_path):
    """Test that ## Options section appears when options_json is set"""
    log_path = str(user_path / "logs_with_options.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    start = datetime.datetime.now(datetime.timezone.utc)

    # Create response with options
    db["responses"].insert(
        {
            "id": str(monotonic_ulid()).lower(),
            "system": "system",
            "prompt": "prompt",
            "response": "response",
            "model": "davinci",
            "datetime_utc": start.isoformat(),
            "conversation_id": "abc123",
            "input_tokens": 2,
            "output_tokens": 5,
            "options_json": json.dumps(
                {"thinking_level": "high", "media_resolution": "low"}
            ),
        }
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-p", str(log_path)], catch_exceptions=False)
    assert result.exit_code == 0
    output = result.output

    # Verify ## Options section is present
    assert "## Options\n\n" in output
    assert "- thinking_level: high" in output
    assert "- media_resolution: low" in output


def test_logs_token_usage_details_are_markdown_code(user_path):
    log_path = str(user_path / "logs_token_details.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    db["responses"].insert(
        {
            "id": str(monotonic_ulid()).lower(),
            "system": None,
            "prompt": "prompt",
            "response": "response",
            "model": "davinci",
            "datetime_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "conversation_id": "abc123",
            "input_tokens": 2,
            "output_tokens": 5,
            "token_details": json.dumps(
                {
                    "output_tokens_details": {
                        "reasoning_tokens": 1,
                        "label": "`reasoning`",
                    }
                }
            ),
        }
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-p", log_path, "-u"], catch_exceptions=False)
    assert result.exit_code == 0
    assert (
        '## Token usage\n\n2 input, 5 output, ``{"output_tokens_details": '
        '{"reasoning_tokens": 1, "label": "`reasoning`"}}``\n'
    ) in result.output


@pytest.mark.parametrize(
    ("duration_ms", "expected"),
    (
        (23_347, "23347ms (23s)"),
        (35_000, "35000ms (35s)"),
        (94_000, "94000ms (1m 34s)"),
        (5_582_000, "5582000ms (1h 33m 2s)"),
    ),
)
def test_logs_duration_in_usage_markdown(user_path, duration_ms, expected):
    log_path = str(user_path / "logs_duration.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    db["responses"].insert(
        {
            "id": str(monotonic_ulid()).lower(),
            "prompt": "prompt",
            "response": "response",
            "model": "davinci",
            "datetime_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "conversation_id": "abc123",
            "input_tokens": 2,
            "output_tokens": 5,
            "duration_ms": duration_ms,
        }
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-p", log_path, "-u"], catch_exceptions=False)
    assert result.exit_code == 0
    assert (
        f"## Token usage\n\n2 input, 5 output\n\nDuration: {expected}\n"
        in result.output
    )


@pytest.mark.parametrize("n", (None, 0, 2))
def test_logs_json(n, log_path):
    "Test that logs command correctly returns requested -n records"
    runner = CliRunner()
    args = ["logs", "-p", str(log_path), "--json"]
    if n is not None:
        args.extend(["-n", str(n)])
    result = runner.invoke(cli, args, catch_exceptions=False)
    assert result.exit_code == 0
    logs = json.loads(result.output)
    expected_length = 3
    if n is not None:
        if n == 0:
            expected_length = 100
        else:
            expected_length = n
    assert len(logs) == expected_length


@pytest.mark.parametrize(
    "args", (["-r"], ["--response"], ["list", "-r"], ["list", "--response"])
)
def test_logs_response_only(args, log_path):
    "Test that logs -r/--response returns just the last response"
    runner = CliRunner()
    result = runner.invoke(cli, ["logs"] + args, catch_exceptions=False)
    assert result.exit_code == 0
    assert result.output == 'response\n```python\nprint("hello word")\n```\n'


@pytest.mark.parametrize(
    "args",
    (
        ["-x"],
        ["--extract"],
        ["list", "-x"],
        ["list", "--extract"],
        # Using -xr together should have same effect as just -x
        ["-xr"],
        ["-x", "-r"],
        ["--extract", "--response"],
    ),
)
def test_logs_extract_first_code(args, log_path):
    "Test that logs -x/--extract returns the first code block"
    runner = CliRunner()
    result = runner.invoke(cli, ["logs"] + args, catch_exceptions=False)
    assert result.exit_code == 0
    assert result.output == 'print("hello word")\n\n'


@pytest.mark.parametrize(
    "args",
    (
        ["--xl"],
        ["--extract-last"],
        ["list", "--xl"],
        ["list", "--extract-last"],
        ["--xl", "-r"],
        ["-x", "--xl"],
    ),
)
def test_logs_extract_last_code(args, log_path):
    "Test that logs --xl/--extract-last returns the last code block"
    runner = CliRunner()
    result = runner.invoke(cli, ["logs"] + args, catch_exceptions=False)
    assert result.exit_code == 0
    assert result.output == 'print("hello word")\n\n'


@pytest.mark.parametrize("arg", ("-s", "--short"))
@pytest.mark.parametrize("usage", (None, "-u", "--usage"))
def test_logs_short(log_path, arg, usage):
    runner = CliRunner()
    args = ["logs", arg, "-p", str(log_path)]
    if usage:
        args.append(usage)
    result = runner.invoke(cli, args)
    assert result.exit_code == 0
    output = datetime_re.sub("YYYY-MM-DDTHH:MM:SS", result.output)
    expected_usage = ""
    if usage:
        expected_usage = "  usage:\n    input: 2\n    output: 5\n"
    expected = (
        "- model: davinci\n"
        "  datetime: 'YYYY-MM-DDTHH:MM:SS'\n"
        "  duration_ms: null\n"
        "  conversation: abc123\n"
        "  system: system\n"
        "  prompt: prompt\n"
        "  prompt_fragments: []\n"
        f"  system_fragments: []\n{expected_usage}"
        "- model: davinci\n"
        "  datetime: 'YYYY-MM-DDTHH:MM:SS'\n"
        "  duration_ms: null\n"
        "  conversation: abc123\n"
        "  system: system\n"
        "  prompt: prompt\n"
        "  prompt_fragments: []\n"
        f"  system_fragments: []\n{expected_usage}"
        "- model: davinci\n"
        "  datetime: 'YYYY-MM-DDTHH:MM:SS'\n"
        "  duration_ms: null\n"
        "  conversation: abc123\n"
        "  system: system\n"
        "  prompt: prompt\n"
        "  prompt_fragments: []\n"
        f"  system_fragments: []\n{expected_usage}"
    )
    assert output == expected


def test_logs_short_always_includes_duration_ms(user_path):
    log_path = str(user_path / "logs_short_duration.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    db["responses"].insert(
        {
            "id": str(monotonic_ulid()).lower(),
            "prompt": "prompt",
            "response": "response",
            "model": "davinci",
            "datetime_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "conversation_id": "abc123",
            "duration_ms": 23_347,
        }
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-p", log_path, "--short"])
    assert result.exit_code == 0
    assert "  duration_ms: 23347\n" in result.output
    assert "  usage:" not in result.output


@pytest.mark.xfail(sys.platform == "win32", reason="Expected to fail on Windows")
@pytest.mark.parametrize("env", ({}, {"LLM_USER_PATH": "/tmp/llm-user-path"}))
def test_logs_path(monkeypatch, env, user_path):
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "path"])
    assert result.exit_code == 0
    if env:
        expected = env["LLM_USER_PATH"] + "/logs.db"
    else:
        expected = str(user_path) + "/logs.db"
    assert result.output.strip() == expected


@pytest.mark.parametrize("model", ("davinci", "curie"))
@pytest.mark.parametrize("path_option", (None, "-p", "--path", "-d", "--database"))
def test_logs_filtered(user_path, model, path_option):
    log_path = str(user_path / "logs.db")
    if path_option:
        log_path = str(user_path / "logs_alternative.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    db["responses"].insert_all(
        {
            "id": str(monotonic_ulid()).lower(),
            "system": "system",
            "prompt": "prompt",
            "response": "response",
            "model": "davinci" if i % 2 == 0 else "curie",
        }
        for i in range(100)
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["logs", "list", "-m", model, "--json"]
        + ([path_option, log_path] if path_option else []),
    )
    assert result.exit_code == 0
    records = json.loads(result.output.strip())
    assert all(record["model"] == model for record in records)


def test_logs_search_new_tables(mock_model, logs_db):
    runner = CliRunner()
    mock_model.enqueue(["A fine city"])
    runner.invoke(
        cli, ["-m", "mock", "tell me about Ljubljana"], catch_exceptions=False
    )
    mock_model.enqueue(["Try httpx-retries for that"])
    runner.invoke(
        cli, ["-m", "mock", "what retry library should I use"], catch_exceptions=False
    )

    # Matches prompt text
    result = runner.invoke(
        cli, ["logs", "-q", "Ljubljana", "--json"], catch_exceptions=False
    )
    assert result.exit_code == 0
    rows = json.loads(result.output)
    assert [row["prompt"] for row in rows] == ["tell me about Ljubljana"]

    # Matches response text
    result2 = runner.invoke(
        cli, ["logs", "-q", "httpx", "--json"], catch_exceptions=False
    )
    assert result2.exit_code == 0
    rows2 = json.loads(result2.output)
    assert [row["response"] for row in rows2] == ["Try httpx-retries for that"]


def test_logs_search_prompt_outranks_response(mock_model, logs_db):
    # The prompt column carries a much higher bm25 weight: what you
    # typed says more about what a turn is about than what came back.
    runner = CliRunner()
    mock_model.enqueue(["I recommend a python one-liner"])
    runner.invoke(cli, ["-m", "mock", "how do I sort a list"], catch_exceptions=False)
    mock_model.enqueue(["Use yield"])
    runner.invoke(
        cli, ["-m", "mock", "explain python generators"], catch_exceptions=False
    )
    result = runner.invoke(
        cli, ["logs", "-q", "python", "--json"], catch_exceptions=False
    )
    assert result.exit_code == 0
    rows = json.loads(result.output)
    assert [row["prompt"] for row in rows] == [
        "explain python generators",
        "how do I sort a list",
    ]


def test_logs_search_excludes_fragment_content(mock_model, logs_db, tmpdir):
    fragment_path = str(tmpdir / "notes.txt")
    with open(fragment_path, "w", encoding="utf-8") as fp:
        fp.write("Wombats are sturdy quadrupedal marsupials")
    runner = CliRunner()
    mock_model.enqueue(["They do indeed"])
    runner.invoke(
        cli,
        ["-m", "mock", "-f", fragment_path, "do zebras have stripes"],
        catch_exceptions=False,
    )
    # The typed question is searchable
    found = runner.invoke(
        cli, ["logs", "-q", "zebras", "--json"], catch_exceptions=False
    )
    assert len(json.loads(found.output)) == 1
    # The fragment's content is not
    not_found = runner.invoke(
        cli, ["logs", "-q", "wombats", "--json"], catch_exceptions=False
    )
    assert json.loads(not_found.output) == []


def test_logs_search_merges_legacy_rows(mock_model, logs_db):
    # A legacy-only row and a new turn matching the same query both
    # come back from one search.
    migrate(logs_db)
    logs_db["responses"].insert(
        {
            "id": "01aaaaaaaaaaaaaaaaaaaaaaaa",
            "system": None,
            "prompt": "name a pet pelican",
            "response": "Percy",
            "model": "davinci",
            "datetime_utc": "2025-01-01T00:00:00",
        },
        alter=True,
    )
    runner = CliRunner()
    mock_model.enqueue(["Scoop"])
    runner.invoke(
        cli, ["-m", "mock", "another pelican name please"], catch_exceptions=False
    )
    result = runner.invoke(
        cli, ["logs", "-q", "pelican", "--json"], catch_exceptions=False
    )
    assert result.exit_code == 0
    prompts = {row["prompt"] for row in json.loads(result.output)}
    assert prompts == {"name a pet pelican", "another pelican name please"}


def test_logs_search_bad_query_is_a_clean_error(logs_db):
    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-q", 'unbalanced"quote'])
    assert result.exit_code == 1
    assert "Invalid search query" in result.output


@pytest.mark.parametrize(
    "query,extra_args,expected",
    (
        # With no search term order should be by datetime
        ("", [], ["doc1", "doc2", "doc3"]),
        # With a search it's order by rank instead - best match first.
        # doc3 says llama twice. (The old implementation ordered by
        # `rank desc`, which with bm25's negative-is-better scores put
        # the weakest matches first; that sign bug is fixed.)
        ("llama", [], ["doc3", "doc1"]),
        ("alpaca", [], ["doc2"]),
        # Model filter should work too
        ("llama", ["-m", "davinci"], ["doc3", "doc1"]),
        ("llama", ["-m", "davinci2"], []),
        # Adding -l/--latest should return latest first (order by id desc)
        ("llama", ["-l"], ["doc3", "doc1"]),
        ("llama", ["--latest"], ["doc3", "doc1"]),
    ),
)
def test_logs_search(user_path, query, extra_args, expected):
    log_path = str(user_path / "logs.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)

    def _insert(id, text):
        db["responses"].insert(
            {
                "id": id,
                "system": "system",
                "prompt": text,
                "response": "response",
                "model": "davinci",
            }
        )

    _insert("doc1", "llama")
    _insert("doc2", "alpaca")
    _insert("doc3", "llama llama")
    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "list", "-q", query, "--json"] + extra_args)
    assert result.exit_code == 0
    records = json.loads(result.output.strip())
    assert [record["id"] for record in records] == expected


@pytest.mark.parametrize(
    "args,expected",
    (
        (["--data", "--schema", SINGLE_ID], '{"name": "1"}\n{"name": "0"}\n'),
        (
            ["--data", "--schema", MULTI_ID],
            (
                '{"items": [{"name": "one"}, {"name": "two"}]}\n'
                '{"items": [{"name": "one"}, {"name": "two"}]}\n'
                '{"items": [{"name": "one"}, {"name": "two"}]}\n'
                '{"items": [{"name": "one"}, {"name": "two"}]}\n'
            ),
        ),
        (
            ["--data-array", "--schema", MULTI_ID],
            (
                '[{"items": [{"name": "one"}, {"name": "two"}]},\n'
                ' {"items": [{"name": "one"}, {"name": "two"}]},\n'
                ' {"items": [{"name": "one"}, {"name": "two"}]},\n'
                ' {"items": [{"name": "one"}, {"name": "two"}]}]\n'
            ),
        ),
        (
            ["--schema", MULTI_ID, "--data-key", "items"],
            (
                '{"name": "one"}\n'
                '{"name": "two"}\n'
                '{"name": "one"}\n'
                '{"name": "two"}\n'
                '{"name": "one"}\n'
                '{"name": "two"}\n'
                '{"name": "one"}\n'
                '{"name": "two"}\n'
            ),
        ),
    ),
)
def test_logs_schema(schema_log_path, args, expected):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["logs", "-n", "0", "-p", str(schema_log_path)] + args,
        catch_exceptions=False,
    )
    assert result.exit_code == 0
    assert result.output == expected


def test_logs_schema_data_ids(schema_log_path):
    db = sqlite_utils.Database(schema_log_path)
    ulid = ULID.from_timestamp(time.time() + 100)
    db["responses"].insert(
        {
            "id": str(ulid).lower(),
            "system": "system",
            "prompt": "prompt",
            "response": json.dumps(
                {
                    "name": "three",
                    "response_id": 1,
                    "conversation_id": 2,
                    "conversation_id_": 3,
                }
            ),
            "model": "davinci",
            "datetime_utc": ulid.datetime.isoformat(),
            "conversation_id": "abc123",
            "input_tokens": 2,
            "output_tokens": 5,
            "schema_id": SINGLE_ID,
        }
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "logs",
            "-n",
            "0",
            "-p",
            str(schema_log_path),
            "--data-ids",
            "--data-key",
            "items",
            "--data-array",
        ],
        catch_exceptions=False,
    )
    assert result.exit_code == 0
    rows = json.loads(result.output)
    last_row = rows.pop(-1)
    assert set(last_row.keys()) == {
        "conversation_id_",
        "conversation_id",
        "response_id",
        "response_id_",
        "name",
        "conversation_id__",
    }
    assert last_row["response_id_"] == str(ulid).lower()
    assert last_row["conversation_id__"] == "abc123"
    for row in rows:
        assert set(row.keys()) == {"conversation_id", "response_id", "name"}
        assert row["conversation_id"] in {"abc123", "abc456"}
        assert row["conversation_id"] != row["response_id"]


_expected_yaml_re = r"""- id: [a-f0-9]{32}
  summary: \|
    
  usage: \|
    4 times, most recently \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}\+00:00
- id: [a-f0-9]{32}
  summary: \|
    
  usage: \|
    2 times, most recently \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}\+00:00"""


@pytest.mark.parametrize(
    "args,expected",
    (
        (["schemas"], _expected_yaml_re),
        (["schemas", "list"], _expected_yaml_re),
    ),
)
def test_schemas_list_yaml(schema_log_path, args, expected):
    result = CliRunner().invoke(cli, args + ["-d", str(schema_log_path)])
    assert result.exit_code == 0
    assert re.match(expected, result.output.strip())


@pytest.mark.parametrize("is_nl", (False, True))
def test_schemas_list_json(schema_log_path, is_nl):
    result = CliRunner().invoke(
        cli,
        ["schemas", "list"]
        + (["--nl"] if is_nl else ["--json"])
        + ["-d", str(schema_log_path)],
    )
    assert result.exit_code == 0
    if is_nl:
        rows = [json.loads(line) for line in result.output.strip().split("\n")]
    else:
        rows = json.loads(result.output)
    assert len(rows) == 2
    assert rows[0]["content"] == {"name": "array"}
    assert rows[0]["times_used"] == 4
    assert rows[1]["content"] == {"name": "string"}
    assert rows[1]["times_used"] == 2
    assert set(rows[0].keys()) == {"id", "content", "recently_used", "times_used"}


@pytest.fixture
def fragments_fixture(user_path):
    log_path = str(user_path / "logs_fragments.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    start = datetime.datetime.now(datetime.timezone.utc)
    # Replace everything from here on

    fragment_hashes_by_slug = {}
    # Create fragments
    for i in range(1, 6):
        content = f"This is fragment {i}" * (100 if i == 5 else 1)
        fragment = Fragment(content, "fragment")
        db["fragments"].insert(
            {
                "id": i,
                "hash": fragment.id(),
                # 5 is a long one:
                "content": content,
                "datetime_utc": start.isoformat(),
            }
        )
        db["fragment_aliases"].insert({"alias": f"hash{i}", "fragment_id": i})
        fragment_hashes_by_slug[f"hash{i}"] = fragment.id()

    # Create some more fragment aliases
    db["fragment_aliases"].insert({"alias": "alias_1", "fragment_id": 3})
    db["fragment_aliases"].insert({"alias": "alias_3", "fragment_id": 4})
    db["fragment_aliases"].insert({"alias": "long_5", "fragment_id": 5})

    def make_response(name, prompt_fragment_ids=None, system_fragment_ids=None):
        time.sleep(0.05)  # To ensure ULIDs order predictably
        response_id = str(ULID.from_timestamp(time.time())).lower()
        db["responses"].insert(
            {
                "id": response_id,
                "system": f"system: {name}",
                "prompt": f"prompt: {name}",
                "response": f"response: {name}",
                "model": "davinci",
                "datetime_utc": start.isoformat(),
                "conversation_id": "abc123",
                "input_tokens": 2,
                "output_tokens": 5,
            }
        )
        # Link fragments to this response
        for fragment_id in prompt_fragment_ids or []:
            db["prompt_fragments"].insert(
                {"response_id": response_id, "fragment_id": fragment_id}
            )
        for fragment_id in system_fragment_ids or []:
            db["system_fragments"].insert(
                {"response_id": response_id, "fragment_id": fragment_id}
            )
        return {name: response_id}

    collected = {}
    collected.update(make_response("no_fragments"))
    collected.update(
        single_prompt_fragment_id=make_response("single_prompt_fragment", [1])
    )
    collected.update(
        single_system_fragment_id=make_response("single_system_fragment", None, [2])
    )
    collected.update(
        multi_prompt_fragment_id=make_response("multi_prompt_fragment", [1, 2])
    )
    collected.update(
        multi_system_fragment_id=make_response("multi_system_fragment", None, [1, 2])
    )
    collected.update(both_fragments_id=make_response("both_fragments", [1, 2], [3, 4]))
    collected.update(
        single_long_prompt_fragment_with_alias_id=make_response(
            "single_long_prompt_fragment_with_alias", [5], None
        )
    )
    collected.update(
        single_system_fragment_with_alias_id=make_response(
            "single_system_fragment_with_alias", None, [4]
        )
    )
    return {
        "path": log_path,
        "fragment_hashes_by_slug": fragment_hashes_by_slug,
        "collected": collected,
    }


@pytest.mark.parametrize(
    "fragment_refs,expected",
    (
        (
            ["hash1"],
            [
                {
                    "name": "single_prompt_fragment",
                    "prompt_fragments": ["hash1"],
                    "system_fragments": [],
                },
                {
                    "name": "multi_prompt_fragment",
                    "prompt_fragments": ["hash1", "hash2"],
                    "system_fragments": [],
                },
                {
                    "name": "multi_system_fragment",
                    "prompt_fragments": [],
                    "system_fragments": ["hash1", "hash2"],
                },
                {
                    "name": "both_fragments",
                    "prompt_fragments": ["hash1", "hash2"],
                    "system_fragments": ["hash3", "hash4"],
                },
            ],
        ),
        (
            ["alias_3"],
            [
                {
                    "name": "both_fragments",
                    "prompt_fragments": ["hash1", "hash2"],
                    "system_fragments": ["hash3", "hash4"],
                },
                {
                    "name": "single_system_fragment_with_alias",
                    "prompt_fragments": [],
                    "system_fragments": ["hash4"],
                },
            ],
        ),
        # Testing for AND condition
        (
            ["hash1", "hash4"],
            [
                {
                    "name": "both_fragments",
                    "prompt_fragments": ["hash1", "hash2"],
                    "system_fragments": ["hash3", "hash4"],
                },
            ],
        ),
    ),
)
def test_logs_fragments(fragments_fixture, fragment_refs, expected):
    fragments_log_path = fragments_fixture["path"]
    fragment_hashes_by_slug = fragments_fixture["fragment_hashes_by_slug"]
    runner = CliRunner()
    args = ["logs", "-d", fragments_log_path, "-n", "0"]
    for ref in fragment_refs:
        args.extend(["-f", ref])
    result = runner.invoke(cli, args + ["--json"], catch_exceptions=False)
    assert result.exit_code == 0
    output = result.output
    responses = json.loads(output)
    # Re-shape that to same shape as expected
    reshaped = [
        {
            "name": response["prompt"].replace("prompt: ", ""),
            "prompt_fragments": [
                fragment["hash"] for fragment in response["prompt_fragments"]
            ],
            "system_fragments": [
                fragment["hash"] for fragment in response["system_fragments"]
            ],
        }
        for response in responses
    ]
    # Replace aliases with hash IDs in expected
    for item in expected:
        item["prompt_fragments"] = [
            fragment_hashes_by_slug.get(ref, ref) for ref in item["prompt_fragments"]
        ]
        item["system_fragments"] = [
            fragment_hashes_by_slug.get(ref, ref) for ref in item["system_fragments"]
        ]
    assert reshaped == expected
    # Now test the `-s/--short` option:
    result2 = runner.invoke(cli, args + ["-s"], catch_exceptions=False)
    assert result2.exit_code == 0
    output2 = result2.output
    loaded = yaml.safe_load(output2)
    reshaped2 = [
        {
            "name": item["prompt"].replace("prompt: ", ""),
            "system_fragments": item["system_fragments"],
            "prompt_fragments": item["prompt_fragments"],
        }
        for item in loaded
    ]
    assert reshaped2 == expected


def test_logs_fragments_markdown(fragments_fixture):
    fragments_log_path = fragments_fixture["path"]
    fragment_hashes_by_slug = fragments_fixture["fragment_hashes_by_slug"]
    runner = CliRunner()
    args = ["logs", "-d", fragments_log_path, "-n", "0"]
    result = runner.invoke(cli, args, catch_exceptions=False)
    assert result.exit_code == 0
    output = result.output
    # Replace dates and IDs
    output = datetime_re.sub("YYYY-MM-DDTHH:MM:SS", output)
    output = id_re.sub("id: xxx", output)
    expected_output = """
# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: no_fragments

## System

system: no_fragments

## Response

response: no_fragments

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: single_prompt_fragment

### Prompt fragments

- hash1

## System

system: single_prompt_fragment

## Response

response: single_prompt_fragment

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: single_system_fragment

## System

system: single_system_fragment

### System fragments

- hash2

## Response

response: single_system_fragment

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: multi_prompt_fragment

### Prompt fragments

- hash1
- hash2

## System

system: multi_prompt_fragment

## Response

response: multi_prompt_fragment

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: multi_system_fragment

## System

system: multi_system_fragment

### System fragments

- hash1
- hash2

## Response

response: multi_system_fragment

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: both_fragments

### Prompt fragments

- hash1
- hash2

## System

system: both_fragments

### System fragments

- hash3
- hash4

## Response

response: both_fragments

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: single_long_prompt_fragment_with_alias

### Prompt fragments

- hash5

## System

system: single_long_prompt_fragment_with_alias

## Response

response: single_long_prompt_fragment_with_alias

# YYYY-MM-DDTHH:MM:SS    conversation: abc123 id: xxx

Model: **davinci**

## Prompt

prompt: single_system_fragment_with_alias

## System

system: single_system_fragment_with_alias

### System fragments

- hash4

## Response

response: single_system_fragment_with_alias
    """
    # Replace hash4 etc with their proper IDs
    for key, value in fragment_hashes_by_slug.items():
        expected_output = expected_output.replace(key, value)
    assert output.strip() == expected_output.strip()


@pytest.mark.parametrize("arg", ("-e", "--expand"))
def test_expand_fragment_json(fragments_fixture, arg):
    fragments_log_path = fragments_fixture["path"]
    runner = CliRunner()
    args = ["logs", "-d", fragments_log_path, "-f", "long_5", "--json"]
    # Without -e the JSON is truncated
    result = runner.invoke(cli, args, catch_exceptions=False)
    assert result.exit_code == 0
    data = json.loads(result.output)
    fragment = data[0]["prompt_fragments"][0]["content"]
    assert fragment.startswith("This is fragment 5This is fragment 5")
    assert len(fragment) < 200
    # With -e the JSON is expanded
    result2 = runner.invoke(cli, args + [arg], catch_exceptions=False)
    assert result2.exit_code == 0
    data2 = json.loads(result2.output)
    fragment2 = data2[0]["prompt_fragments"][0]["content"]
    assert fragment2.startswith("This is fragment 5This is fragment 5")
    assert len(fragment2) > 200


def test_expand_fragment_markdown(fragments_fixture):
    fragments_log_path = fragments_fixture["path"]
    fragment_hashes_by_slug = fragments_fixture["fragment_hashes_by_slug"]
    runner = CliRunner()
    args = ["logs", "-d", fragments_log_path, "-f", "long_5", "--expand"]
    result = runner.invoke(cli, args, catch_exceptions=False)
    assert result.exit_code == 0
    output = result.output
    interesting_bit = (
        output.split("prompt: single_long_prompt_fragment_with_alias")[1]
        .split("## System")[0]
        .strip()
    )
    hash = fragment_hashes_by_slug["hash5"]
    expected_prefix = f"### Prompt fragments\n\n<details><summary>{hash}</summary>\nThis is fragment 5"
    assert interesting_bit.startswith(expected_prefix)
    assert interesting_bit.endswith("</details>")


def test_logs_tools(logs_db):
    runner = CliRunner()
    code = textwrap.dedent("""
    def demo():
        return "one\\ntwo\\nthree"
    """)
    result1 = runner.invoke(
        cli,
        [
            "-m",
            "echo",
            "--functions",
            code,
            json.dumps({"tool_calls": [{"name": "demo"}]}),
        ],
    )
    assert result1.exit_code == 0
    result2 = runner.invoke(cli, ["logs", "-c"])
    normalized_output = re.sub(r"tc_[0-9a-z]{26}", "tc_TCID", result2.output)
    assert (
        "### Tool results\n"
        "\n"
        "- **demo**: `tc_TCID`  \n"
        "    ```\n"
        "    one\n"
        "    two\n"
        "    three\n"
        "    ```\n"
        "\n"
    ) in normalized_output
    # Log one that did NOT use tools, check that `llm logs --tools` ignores it
    assert runner.invoke(cli, ["-m", "echo", "badger"]).exit_code == 0
    assert "badger" in runner.invoke(cli, ["logs"]).output
    logs_tools_output = runner.invoke(cli, ["logs", "--tools"]).output
    assert "badger" not in logs_tools_output
    assert "three" in logs_tools_output


def test_logs_repeated_tools_use_short_hash(logs_db):
    runner = CliRunner()
    code = textwrap.dedent("""
    def demo():
        return "ok"
    """)
    args = [
        "-m",
        "echo",
        "--functions",
        code,
        json.dumps({"tool_calls": [{"name": "demo"}]}),
    ]
    result1 = runner.invoke(cli, args)
    assert result1.exit_code == 0
    result2 = runner.invoke(cli, args)
    assert result2.exit_code == 0

    result3 = runner.invoke(cli, ["logs", "-n", "2"])
    assert result3.exit_code == 0
    tool_hashes = re.findall(r"- \*\*demo\*\*: `([0-9a-f]+)`", result3.output)
    assert len(tool_hashes) == 2
    assert len(tool_hashes[0]) == 64
    assert tool_hashes[1] == tool_hashes[0][:7]


def test_logs_tool_call_argument_formatting(logs_db):
    runner = CliRunner()
    code = textwrap.dedent("""
    def demo(timeout: int, options: list):
        return "ok"
    """)
    result1 = runner.invoke(
        cli,
        [
            "-m",
            "echo",
            "--functions",
            code,
            json.dumps(
                {
                    "tool_calls": [
                        {
                            "name": "demo",
                            "arguments": {
                                "timeout": 120,
                                "options": ["`tick`"],
                            },
                        }
                    ]
                }
            ),
        ],
    )
    assert result1.exit_code == 0
    result2 = runner.invoke(cli, ["logs", "-c"])
    normalized_output = re.sub(r"tc_[0-9a-z]{26}", "tc_TCID", result2.output)
    assert (
        "### Tool calls\n"
        "\n"
        "- **demo**: `tc_TCID`  \n"
        "    timeout: `120`\n"
        '    options: ``["`tick`"]``\n'
    ) in normalized_output


def test_logs_server_side_tool_results(logs_db, mock_model):
    """Server-executed tool calls carry their results inside the
    response itself, so they render in a Tool results section under
    ## Response - https://github.com/simonw/llm/issues/1629"""
    import llm

    mock_model.enqueue(
        [
            llm.parts.StreamEvent(
                type="tool_call_name",
                chunk="shell",
                tool_call_id="tc_server_1",
                server_executed=True,
            ),
            llm.parts.StreamEvent(
                type="tool_call_args",
                chunk='{"commands": ["python fib.py"]}',
                tool_call_id="tc_server_1",
                server_executed=True,
            ),
            llm.parts.StreamEvent(
                type="tool_result",
                chunk="17711",
                tool_name="shell",
                tool_call_id="tc_server_1",
                server_executed=True,
            ),
            llm.parts.StreamEvent(type="text", chunk="Fibonacci(22) = 17711"),
        ]
    )
    response = mock_model.prompt("calculate fibonacci 22")
    response.text()
    response.log_to_db(logs_db)

    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-c"], catch_exceptions=False)
    assert result.exit_code == 0
    assert (
        "## Response\n"
        "\n"
        "### Tool calls\n"
        "\n"
        "- **shell**: `tc_server_1`  \n"
        '    commands: `["python fib.py"]`\n'
        "\n"
        "### Tool results\n"
        "\n"
        "- **shell**: `tc_server_1`  \n"
        "    ```\n"
        "    17711\n"
        "    ```\n"
        "\n"
        "Fibonacci(22) = 17711\n"
    ) in result.output

    # --json output records the result and marks it server-executed
    json_result = runner.invoke(cli, ["logs", "--json"], catch_exceptions=False)
    assert json_result.exit_code == 0
    row = json.loads(json_result.output)[0]
    assert row["tool_calls"][0]["server_executed"] is True
    (tool_result,) = row["tool_results"]
    assert tool_result["name"] == "shell"
    assert tool_result["output"] == "17711"
    assert tool_result["tool_call_id"] == "tc_server_1"
    assert tool_result["server_executed"] is True
    assert tool_result["id"] is not None

    # --short mode includes the server-side result too
    short_result = runner.invoke(cli, ["logs", "--short"], catch_exceptions=False)
    assert short_result.exit_code == 0
    assert "shell: 17711" in short_result.output


def test_logs_backup(logs_db, tmp_path, monkeypatch):
    assert not logs_db.tables
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    runner.invoke(cli, ["-m", "echo", "simple prompt"])
    assert logs_db.tables
    expected_path = pathlib.Path("backup.db")
    assert not expected_path.exists()
    # Now back it up
    result = runner.invoke(cli, ["logs", "backup", "backup.db"])
    assert result.exit_code == 0
    assert result.output.startswith("Backed up ")
    assert result.output.endswith("to backup.db\n")
    assert expected_path.exists()


def test_logs_status_counts_threads_and_turns(logs_db):
    runner = CliRunner()
    runner.invoke(cli, ["-m", "echo", "simple prompt"])
    result = runner.invoke(cli, ["logs", "status"])
    assert result.exit_code == 0
    assert "Number of threads logged:\t1" in result.output
    assert "Number of turns logged:\t\t1" in result.output
    # No legacy rows, so the legacy lines should be hidden
    assert "legacy" not in result.output
    # Legacy counts show up once legacy tables have rows
    logs_db["conversations"].insert({"id": "abc", "name": "test", "model": "echo"})
    result2 = runner.invoke(cli, ["logs", "status"])
    assert result2.exit_code == 0
    assert "Number of legacy conversations:\t1" in result2.output
    assert "Number of legacy responses:\t0" in result2.output


@pytest.mark.parametrize("async_", (False, True))
def test_logs_resolved_model(logs_db, mock_model, async_mock_model, async_):
    mock_model.resolved_model_name = "resolved-mock"
    async_mock_model.resolved_model_name = "resolved-mock"
    runner = CliRunner()
    result = runner.invoke(
        cli, ["-m", "mock", "simple prompt"] + (["--async"] if async_ else [])
    )
    assert result.exit_code == 0
    # Should have logged the resolved model name
    assert logs_db["turns"].count
    turn = next(iter(logs_db["turns"].rows))
    assert turn["model"] == "mock"
    assert turn["resolved_model"] == "resolved-mock"

    # Should show up in the JSON logs
    result2 = runner.invoke(cli, ["logs", "--json"])
    assert result2.exit_code == 0
    logs = json.loads(result2.output.strip())
    assert len(logs) == 1
    assert logs[0]["model"] == "mock"
    assert logs[0]["resolved_model"] == "resolved-mock"

    # And the rendered logs
    result3 = runner.invoke(cli, ["logs"])
    assert "Model: **mock** (resolved: **resolved-mock**)" in result3.output


# ---- Reasoning persistence and markdown rendering -----------------


def test_log_to_db_persists_visible_reasoning(logs_db, mock_model):
    """A response that streams reasoning events should round-trip the
    visible reasoning text via a ReasoningPart in the stored chain."""
    import llm
    from llm.logs import LogStore, merged_log_rows

    mock_model.enqueue(
        [
            llm.parts.StreamEvent(type="reasoning", chunk="thinking "),
            llm.parts.StreamEvent(type="reasoning", chunk="hard"),
            llm.parts.StreamEvent(type="text", chunk="hello"),
        ]
    )
    response = mock_model.prompt("hi")
    response.text()
    response.log_to_db(logs_db)

    row = merged_log_rows(LogStore(logs_db))[0]
    assert row["response"] == "hello"
    assert row["reasoning"] == "thinking hard"


def test_log_to_db_persists_empty_reasoning_when_absent(logs_db, mock_model):
    """No reasoning emitted → null reasoning, never raises."""
    from llm.logs import LogStore, merged_log_rows

    mock_model.enqueue(["just text"])
    response = mock_model.prompt("hi")
    response.text()
    response.log_to_db(logs_db)
    row = merged_log_rows(LogStore(logs_db))[0]
    assert not row["reasoning"]


def test_logs_markdown_renders_reasoning_heading(user_path):
    """When a row has reasoning text, `llm logs` renders a `## Reasoning`
    heading between System and Response."""
    log_path = str(user_path / "logs_with_reasoning.db")
    db = sqlite_utils.Database(log_path)
    migrate(db)
    db["responses"].insert(
        {
            "id": str(monotonic_ulid()).lower(),
            "system": None,
            "prompt": "hi",
            "response": "answer",
            "reasoning": "I thought hard about it.\n\n\n",
            "model": "mock",
            "datetime_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "conversation_id": "c1",
        }
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-p", log_path], catch_exceptions=False)
    assert result.exit_code == 0
    # rstrip() before rendering so trailing newlines from the
    # provider output don't push `## Response` down the page.
    assert "## Reasoning\n\nI thought hard about it.\n\n## Response" in result.output


def test_logs_markdown_omits_reasoning_heading_when_empty(log_path):
    """When reasoning is empty/null, no heading appears (existing
    fixture rows have no reasoning)."""
    runner = CliRunner()
    result = runner.invoke(cli, ["logs", "-p", str(log_path)], catch_exceptions=False)
    assert result.exit_code == 0
    assert "## Reasoning" not in result.output
